"""
PLUGIN-BASED POSTURE DETECTION SYSTEM
- Load plugins from posture_framework/plugins/
- Enable/disable plugins in ENABLED_PLUGINS list
- No code changes needed for new plugins
"""

import cv2
import os
import sys
import numpy as np
from ultralytics import YOLO
import mediapipe as mp
import importlib
import torch

# ============================================================
# CONFIG — ENABLE/DISABLE PLUGINS HERE
# ============================================================

# Add plugin names here (must match .py filename in plugins folder)
ENABLED_PLUGINS = ["raise","finger_count"]

MODEL_PATH = r"D:\child detections\Child-posture\Project\posture_framework\models\yolov8s-pose.pt"
CAMERA_ID = 0

TARGET_WIDTH = 640
TARGET_HEIGHT = 480

print("\n" + "="*60)
print("       PLUGIN-BASED POSTURE DETECTION SYSTEM")
print("="*60 + "\n")

# ============================================================
# GPU CHECK
# ============================================================

if torch.cuda.is_available():
    DEVICE = "cuda"
    print(f"[INFO] GPU Detected → {torch.cuda.get_device_name(0)}")
else:
    DEVICE = "cpu"
    print("[INFO] Running on CPU")

print(f"[INFO] Device set to: {DEVICE.upper()}\n")

# ============================================================
# LOAD YOLO MODEL
# ============================================================

if not os.path.exists(MODEL_PATH):
    print("[ERROR] YOLO model not found!")
    print(f"[ERROR] Path: {MODEL_PATH}")
    sys.exit(1)

print("[INFO] Loading YOLO pose model...")
try:
    model = YOLO(MODEL_PATH)
    model.to(DEVICE)
    
    if model.model.yaml.get("kpt_shape", None) is None:
        print("[ERROR] This is NOT a pose model. Please use yolov8s-pose.pt")
        sys.exit(1)
        
    print("[SUCCESS] YOLO pose model loaded and verified")
except Exception as e:
    print(f"[ERROR] Failed to load YOLO model: {e}")
    sys.exit(1)

# ============================================================
# MEDIAPIPE HANDS INITIALIZATION
# ============================================================

mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils

hands = mp_hands.Hands(
    max_num_hands=2,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

print("[INFO] MediaPipe hands initialized\n")

# ============================================================
# PLUGIN LOADING SYSTEM
# ============================================================

print("-" * 60)
print("[INFO] PLUGIN LOADING SYSTEM")
print("-" * 60)

# Get the absolute path to the project root
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
PLUGINS_DIR = os.path.join(PROJECT_ROOT, "plugins")

print(f"[INFO] Project root: {PROJECT_ROOT}")
print(f"[INFO] Plugins directory: {PLUGINS_DIR}")

# Add plugins directory to Python path
sys.path.insert(0, PLUGINS_DIR)
sys.path.insert(0, PROJECT_ROOT)

plugins = []
loaded_plugin_names = []
plugin_descriptions = []

# Check if plugins directory exists
if not os.path.exists(PLUGINS_DIR):
    print(f"[ERROR] Plugins directory not found: {PLUGINS_DIR}")
    print("[INFO] Creating plugins directory...")
    os.makedirs(PLUGINS_DIR, exist_ok=True)

# List available plugins
print("\n[INFO] Available plugins in plugins/ directory:")
available_plugins = []
for file in os.listdir(PLUGINS_DIR):
    if file.endswith(".py") and not file.startswith("__"):
        plugin_name = file[:-3]  # Remove .py extension
        available_plugins.append(plugin_name)
        print(f"  • {plugin_name}")

print(f"\n[INFO] You have {len(available_plugins)} plugin(s) available")

if not ENABLED_PLUGINS:
    print("\n[WARNING] ENABLED_PLUGINS list is empty!")
    print("[INFO] No plugins will be loaded. Add plugin names to ENABLED_PLUGINS list.")
else:
    print(f"\n[INFO] Loading {len(ENABLED_PLUGINS)} enabled plugin(s)...")
    print("-" * 40)

    for plugin_name in ENABLED_PLUGINS:
        print(f"\n[LOADING] '{plugin_name}'...")
        
        # Check if plugin exists
        plugin_file = os.path.join(PLUGINS_DIR, f"{plugin_name}.py")
        
        if not os.path.exists(plugin_file):
            print(f"[ERROR] Plugin file not found: {plugin_file}")
            print(f"[INFO] Create {plugin_name}.py in the plugins folder")
            continue
        
        try:
            # Import the plugin module
            module = importlib.import_module(plugin_name)
            
            # Check if Plugin class exists
            if hasattr(module, "Plugin"):
                # Create plugin instance
                plugin_instance = module.Plugin()
                plugins.append(plugin_instance)
                
                # Get plugin info
                plugin_display_name = getattr(plugin_instance, 'name', plugin_name.capitalize())
                plugin_description = getattr(plugin_instance, 'description', 'No description')
                
                loaded_plugin_names.append(plugin_display_name)
                plugin_descriptions.append(plugin_description)
                
                print(f"[SUCCESS] ✓ {plugin_display_name}")
                print(f"[INFO]    Description: {plugin_description}")
            else:
                print(f"[ERROR] ✗ Plugin class not found in {plugin_name}.py")
                print(f"[INFO] Make sure your plugin has 'class Plugin:'")
                
        except ImportError as e:
            print(f"[ERROR] ✗ Import failed: {e}")
            print(f"[DEBUG] Python path: {sys.path}")
        except Exception as e:
            print(f"[ERROR] ✗ Failed to load plugin: {e}")

print("-" * 60)

# Final plugin status
if plugins:
    print(f"\n[SUCCESS] {len(plugins)} plugin(s) loaded successfully!")
    print("[INFO] Enabled plugins:")
    for i, (name, desc) in enumerate(zip(loaded_plugin_names, plugin_descriptions)):
        print(f"  {i+1}. {name} - {desc}")
else:
    print(f"\n[WARNING] No plugins loaded!")
    print("[TIPS] Check:")
    print("  1. Plugin exists in plugins/ folder")
    print("  2. Plugin has 'class Plugin:'")
    print("  3. Plugin name in ENABLED_PLUGINS matches filename")
    print("  4. Plugin doesn't have syntax errors")

print("\n" + "="*60)
print("Starting Detection System...")
print("="*60 + "\n")

# ============================================================
# CAMERA INITIALIZATION
# ============================================================

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("[ERROR] Cannot open camera!")
    sys.exit(1)

cap.set(cv2.CAP_PROP_FRAME_WIDTH, TARGET_WIDTH)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, TARGET_HEIGHT)

print("[INFO] Camera started (Press 'Q' to quit)")
print("[INFO] Press 'H' for help, 'D' for debug info")
print("[INFO] Resolution:", TARGET_WIDTH, "x", TARGET_HEIGHT)
print()

# ============================================================
# PLUGIN RUNNER FUNCTION
# ============================================================

def run_plugins(frame, annotated, kpts, hand_res):
    """Run all loaded plugins and collect their messages"""
    messages = []
    colors = []
    plugin_sources = []  # Which plugin generated the message
    
    for plugin in plugins:
        try:
            msg, color = plugin.run(frame, annotated, kpts, hand_res)
            
            if msg and color:
                messages.append(str(msg))
                colors.append(tuple(int(c) for c in color))
                plugin_name = getattr(plugin, 'name', plugin.__class__.__name__)
                plugin_sources.append(plugin_name)
        except Exception as e:
            # Silently skip plugin errors during runtime
            pass
    
    return messages, colors, plugin_sources

# ============================================================
# MAIN LOOP
# ============================================================

frame_count = 0
show_help = False
show_debug = False

while True:
    ret, frame = cap.read()
    if not ret:
        print("[ERROR] Failed to capture frame")
        break
    
    frame_count += 1
    
    # Resize frame for processing
    frame_small = cv2.resize(frame, (TARGET_WIDTH, TARGET_HEIGHT))
    
    # ====================================================
    # YOLO POSE DETECTION
    # ====================================================
    try:
        results = model(frame_small, verbose=False, device=DEVICE)
        annotated = results[0].plot()
        
        # Extract keypoints
        try:
            arr = results[0].keypoints.data.cpu().numpy()
            kpts = arr[0] if len(arr) else None
        except:
            kpts = None
    except Exception as e:
        annotated = frame_small.copy()
        kpts = None
    
    # ====================================================
    # HAND DETECTION (MediaPipe)
    # ====================================================
    rgb = cv2.cvtColor(frame_small, cv2.COLOR_BGR2RGB)
    hand_res = hands.process(rgb)
    
    # Draw hand landmarks
    if hand_res and hand_res.multi_hand_landmarks:
        for hand_landmarks in hand_res.multi_hand_landmarks:
            mp_draw.draw_landmarks(
                annotated, 
                hand_landmarks, 
                mp_hands.HAND_CONNECTIONS,
                mp_draw.DrawingSpec(color=(0, 255, 0), thickness=2, circle_radius=2),
                mp_draw.DrawingSpec(color=(0, 255, 255), thickness=2, circle_radius=2)
            )
    
    # ====================================================
    # RUN PLUGINS
    # ====================================================
    plugin_msgs, plugin_colors, plugin_sources = run_plugins(frame_small, annotated, kpts, hand_res)
    
    # ====================================================
    # DISPLAY SECTION
    # ====================================================
    
    # Draw semi-transparent overlay for status area
    overlay = annotated.copy()
    cv2.rectangle(overlay, (0, 0), (TARGET_WIDTH, 180), (0, 0, 0), -1)
    annotated = cv2.addWeighted(overlay, 0.6, annotated, 0.4, 0)
    
    # Top border
    cv2.rectangle(annotated, (0, 0), (TARGET_WIDTH, 3), (0, 200, 200), -1)
    
    # ----------------------------------------------------
    # SYSTEM HEADER (Top Left)
    # ----------------------------------------------------
    y_pos = 30
    
    # System title
    cv2.putText(annotated, "POSTURE DETECTION SYSTEM", (10, y_pos),
                cv2.FONT_HERSHEY_DUPLEX, 0.8, (255, 255, 255), 2)
    y_pos += 30
    
    # Device info
    device_text = f"Device: {DEVICE.upper()}"
    device_color = (0, 255, 0) if DEVICE == "cuda" else (255, 165, 0)
    cv2.putText(annotated, device_text, (10, y_pos),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, device_color, 2)
    y_pos += 25
    
    # Frame counter
    cv2.putText(annotated, f"Frame: {frame_count}", (10, y_pos),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 200), 1)
    
    # ----------------------------------------------------
    # PLUGIN STATUS (Center Top - MAIN FOCUS)
    # ----------------------------------------------------
    if loaded_plugin_names:
        # Plugin status header
        plugin_header = "ACTIVE PLUGINS"
        header_size = cv2.getTextSize(plugin_header, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)[0]
        header_x = (TARGET_WIDTH - header_size[0]) // 2
        
        cv2.putText(annotated, plugin_header, (header_x, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
        
        # Plugin names
        plugins_text = " | ".join(loaded_plugin_names)
        text_size = cv2.getTextSize(plugins_text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 1)[0]
        text_x = (TARGET_WIDTH - text_size[0]) // 2
        
        # Background for plugin names
        cv2.rectangle(annotated,
                     (text_x - 10, 50),
                     (text_x + text_size[0] + 10, 75),
                     (40, 40, 40), -1)
        cv2.rectangle(annotated,
                     (text_x - 10, 50),
                     (text_x + text_size[0] + 10, 75),
                     (0, 200, 200), 1)
        
        cv2.putText(annotated, plugins_text, (text_x, 70),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 1)
    else:
        # No plugins enabled
        no_plugins_text = "NO PLUGINS ENABLED"
        text_size = cv2.getTextSize(no_plugins_text, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)[0]
        text_x = (TARGET_WIDTH - text_size[0]) // 2
        
        cv2.putText(annotated, no_plugins_text, (text_x, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
    
    # ----------------------------------------------------
    # DETECTION STATUS (Top Right)
    # ----------------------------------------------------
    right_x = TARGET_WIDTH - 150
    status_y = 30
    
    # Person detection
    person_icon = "✓" if kpts is not None else "✗"
    person_color = (0, 255, 0) if kpts is not None else (100, 100, 100)
    cv2.putText(annotated, f"Person: {person_icon}", (right_x, status_y),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, person_color, 2)
    status_y += 25
    
    # Hand detection
    hand_icon = "✓" if (hand_res and hand_res.multi_hand_landmarks) else "✗"
    hand_color = (0, 255, 0) if (hand_res and hand_res.multi_hand_landmarks) else (100, 100, 100)
    cv2.putText(annotated, f"Hands: {hand_icon}", (right_x, status_y),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, hand_color, 2)
    
    # ----------------------------------------------------
    # PLUGIN DETECTION OUTPUTS (Below status area)
    # ----------------------------------------------------
    detection_y = 100
    
    if plugin_msgs:
        # Detection header
        cv2.putText(annotated, "DETECTIONS:", (10, detection_y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        detection_y += 30
        
        # Display each detection with plugin source
        for msg, clr, source in zip(plugin_msgs, plugin_colors, plugin_sources):
            # Draw detection with source
            detection_text = f"[{source}] {msg}"
            cv2.putText(annotated, detection_text, (20, detection_y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, clr, 2)
            detection_y += 35
    else:
        # No detections
        cv2.putText(annotated, "No active detections", (10, detection_y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (150, 150, 150), 1)
        detection_y += 25
    
    # ----------------------------------------------------
    # HELP/DEBUG OVERLAY
    # ----------------------------------------------------
    if show_help:
        help_y = TARGET_HEIGHT - 150
        cv2.rectangle(annotated, (10, help_y - 10), (400, TARGET_HEIGHT - 10), (0, 0, 0), -1)
        cv2.rectangle(annotated, (10, help_y - 10), (400, TARGET_HEIGHT - 10), (0, 200, 200), 2)
        
        help_lines = [
            "KEY CONTROLS:",
            "Q - Quit application",
            "H - Toggle this help",
            "D - Debug info in console",
            "S - Save screenshot",
            "",
            "PLUGIN SYSTEM:",
            f"• {len(loaded_plugin_names)} plugin(s) active",
            "• Add plugins to ENABLED_PLUGINS list",
            "• Create new .py files in plugins/ folder"
        ]
        
        for i, line in enumerate(help_lines):
            cv2.putText(annotated, line, (20, help_y + i * 20),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
    
    if show_debug:
        debug_y = 200
        debug_info = [
            f"Frame: {frame_count}",
            f"Plugins: {len(plugins)} loaded",
            f"Messages: {len(plugin_msgs)} active",
            f"Person: {'Yes' if kpts is not None else 'No'}",
            f"Hands: {'Yes' if hand_res and hand_res.multi_hand_landmarks else 'No'}"
        ]
        
        for i, info in enumerate(debug_info):
            cv2.putText(annotated, info, (TARGET_WIDTH - 200, debug_y + i * 20),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
    
    # ----------------------------------------------------
    # FOOTER
    # ----------------------------------------------------
    # Bottom border
    cv2.rectangle(annotated, (0, TARGET_HEIGHT - 3), (TARGET_WIDTH, TARGET_HEIGHT), (0, 200, 200), -1)
    
    # Help hint
    cv2.putText(annotated, "Press 'H' for help", 
               (10, TARGET_HEIGHT - 10),
               cv2.FONT_HERSHEY_SIMPLEX, 0.5, (150, 150, 150), 1)
    
    # Plugin count
    plugin_count_text = f"Plugins: {len(loaded_plugin_names)}"
    count_width = cv2.getTextSize(plugin_count_text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)[0][0]
    cv2.putText(annotated, plugin_count_text,
               (TARGET_WIDTH - count_width - 10, TARGET_HEIGHT - 10),
               cv2.FONT_HERSHEY_SIMPLEX, 0.5, (150, 150, 150), 1)
    
    # ====================================================
    # SHOW WINDOW
    # ====================================================
    cv2.imshow(f"Posture Detection - {len(loaded_plugin_names)} Plugin(s)", annotated)
    
    # ====================================================
    # KEYBOARD CONTROLS
    # ====================================================
    key = cv2.waitKey(1) & 0xFF
    
    if key == ord('q'):
        print("\n[INFO] Quitting application...")
        break
    elif key == ord('h'):
        show_help = not show_help
        print(f"[INFO] Help {'shown' if show_help else 'hidden'}")
    elif key == ord('d'):
        show_debug = not show_debug
        if show_debug:
            print(f"\n[DEBUG INFO] Frame {frame_count}")
            print(f"  Plugins loaded: {loaded_plugin_names}")
            print(f"  Active messages: {plugin_msgs}")
            print(f"  Keypoints: {'Present' if kpts is not None else 'None'}")
            print(f"  Hands: {'Detected' if hand_res and hand_res.multi_hand_landmarks else 'None'}")
    elif key == ord('s'):
        screenshot_name = f"screenshot_{frame_count}.png"
        cv2.imwrite(screenshot_name, annotated)
        print(f"[INFO] Screenshot saved: {screenshot_name}")

# ============================================================
# CLEANUP
# ============================================================

print("\n" + "="*60)
print("[INFO] Shutting down...")
print("="*60)

cap.release()
hands.close()
cv2.destroyAllWindows()

print(f"\n[INFO] Session Summary:")
print(f"  • Total frames processed: {frame_count}")
print(f"  • Plugins active: {len(loaded_plugin_names)}")
print(f"  • Plugin names: {', '.join(loaded_plugin_names)}")
print(f"  • Device used: {DEVICE.upper()}")
print("\n[INFO] System shutdown complete. Goodbye!\n")