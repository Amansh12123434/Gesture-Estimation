"""
Waving Detection Plugin
Detects left/right hand waving gestures
"""

import numpy as np
from collections import deque

class Plugin:
    def __init__(self):
        self.name = "Waving Detection"
        self.description = "Detects hand waving gestures"
        self.left_hist = deque(maxlen=15)
        self.right_hist = deque(maxlen=15)
        
    def get_side_and_wrist(self, hand):
        """Determine hand side and get wrist position"""
        avg_x = sum(lm.x for lm in hand.landmark) / 21
        side = "Left" if avg_x < 0.5 else "Right"
        wrist_x = hand.landmark[9].x  # MCP joint
        return side, wrist_x

    def detect_wave(self, hist):
        """Detect waving motion from position history"""
        if len(hist) < 8:
            return False

        arr = np.array(hist)
        diffs = np.diff(arr)
        
        # Count direction changes
        sign_changes = np.sum((diffs[:-1] * diffs[1:] < 0))
        amplitude = arr.max() - arr.min()

        return sign_changes >= 2 and amplitude > 0.03

    def run(self, frame, annotated, kpts, hand_res):
        """Main plugin execution - called every frame"""
        # Reset if no hands
        if not (hand_res and hand_res.multi_hand_landmarks):
            self.left_hist.clear()
            self.right_hist.clear()
            return None, None
        
        # Process each hand
        for hand in hand_res.multi_hand_landmarks:
            side, wrist_x = self.get_side_and_wrist(hand)
            
            if side == "Left":
                self.left_hist.append(wrist_x)
            else:
                self.right_hist.append(wrist_x)
        
        # Check waving conditions
        left_waving = self.detect_wave(self.left_hist)
        right_waving = self.detect_wave(self.right_hist)
        
        # Return appropriate message
        if left_waving and right_waving:
            return "BOTH HANDS WAVING 👋👋", (0, 255, 255)  # Yellow
        elif left_waving:
            return "RIGHT HAND WAVING 👋", (255, 100, 0)     # Blue
        elif right_waving:
            return "LEFT HAND WAVING 👋", (255, 255, 0)    # Cyan
        else:
            return None, None