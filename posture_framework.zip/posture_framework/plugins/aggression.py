# plugins/aggression.py
import numpy as np
import time
from collections import deque

class Plugin:
    def __init__(self):
        self.centers = deque(maxlen=8)
        self.times = deque(maxlen=8)
        # keypoint indices
        self.LW = 9; self.RW = 10
        self.LS = 5; self.RS = 6
        self.LH = 11; self.RH = 12

    def arm_raised(self, kpts):
        try:
            lw_y = kpts[self.LW][1]
            rw_y = kpts[self.RW][1]
            ls_y = kpts[self.LS][1]
            rs_y = kpts[self.RS][1]
            left_up = lw_y < ls_y
            right_up = rw_y < rs_y
            return left_up or right_up
        except:
            return False

    def run(self, frame, annotated, kpts, hand_res):
        if kpts is None:
            return None, None
        try:
            t = time.time()
            hip_mid = (kpts[self.LH][:2] + kpts[self.RH][:2]) / 2.0
            self.centers.append(hip_mid)
            self.times.append(t)

            if len(self.centers) < 4:
                return None, None

            dt = self.times[-1] - self.times[0]
            if dt <= 0:
                return None, None
            # approximate forward motion as growth in y-distance to bottom? use displacement magnitude
            dist = np.linalg.norm(self.centers[-1] - self.centers[0])
            speed = dist / dt

            if self.arm_raised(kpts) and speed > 0.03:
                return "POSSIBLE AGGRESSION / FAST APPROACH", (0, 0, 128)
        except Exception:
            return None, None
        return None, None
