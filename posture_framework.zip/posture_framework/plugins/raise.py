"""
Duration-Based Gesture Detection Plugin
For aerial/drone monitoring with clear duration-based alerts
"""

import numpy as np
import time
from collections import deque

class Plugin:
    def __init__(self):
        self.name = "Aerial/Fro Gesture Monitor"
        self.description = "Detects hand raise duration for distress/alert/attention signals"
        
        # Duration thresholds (in seconds)
        self.DISTRESS_DURATION = 5.0      # Both hands raised for 5+ seconds = DISTRESS
        self.ALERT_DURATION = 5.0         # Left hand raised for 5+ seconds = ALERT
        self.ATTENTION_DURATION = 5.0     # Right hand raised for 5+ seconds = ATTENTION
        
        # Detection thresholds (adjusted for aerial view)
        self.RAISE_THRESHOLD = 0.35       # Hand must be above this y-position
        self.MIN_CONFIDENCE = 0.6         # Minimum confidence for detection
        self.DEBOUND_TIME = 0.5           # Time to confirm gesture change
        
        # State tracking
        self.current_gesture = "NONE"     # Current detected gesture
        self.gesture_start_time = None    # When current gesture started
        self.confirmed_gesture = "NONE"   # Gesture confirmed after debouncing
        self.confirmed_start_time = None  # When confirmed gesture started
        
        # Hand tracking
        self.left_hand_state = False      # Is left hand raised?
        self.right_hand_state = False     # Is right hand raised?
        
        # Message display
        self.current_message = ""
        self.message_color = (255, 255, 255)
        self.last_update_time = 0
        
        # History for smoothing
        self.gesture_history = deque(maxlen=10)
        
        # Alert states
        self.distress_triggered = False
        self.alert_triggered = False
        self.attention_triggered = False
        
        print(f"[GESTURE PLUGIN] Thresholds: Distress={self.DISTRESS_DURATION}s, "
              f"Alert={self.ALERT_DURATION}s, Attention={self.ATTENTION_DURATION}s")
    
    def is_hand_raised(self, hand_landmarks):
        """Check if hand is raised (for aerial view)"""
        if not hand_landmarks:
            return False
        
        # For aerial view, we look at the wrist position (landmark 0)
        wrist_y = hand_landmarks.landmark[0].y
        
        # Also check middle finger MCP (landmark 9) for confirmation
        middle_mcp_y = hand_landmarks.landmark[9].y
        
        # Hand is raised if both points are above threshold
        return (wrist_y < self.RAISE_THRESHOLD and 
                middle_mcp_y < self.RAISE_THRESHOLD + 0.1)
    
    def get_hand_side(self, hand_landmarks, handedness=None):
        """Determine if hand is left or right (corrected for mirror)"""
        if handedness:
            # If we have handedness info, correct for mirror
            label = handedness.classification[0].label
            return "RIGHT" if label == "Left" else "LEFT"  # Mirror correction
        
        # Fallback: use position in frame
        avg_x = np.mean([lm.x for lm in hand_landmarks.landmark])
        return "LEFT" if avg_x > 0.5 else "RIGHT"  # Mirror: left appears on right
    
    def detect_current_gesture(self, hand_res):
        """Detect current gesture state"""
        left_raised = False
        right_raised = False
        
        if not (hand_res and hand_res.multi_hand_landmarks):
            return "NONE", False, False
        
        # Check if we have handedness info
        has_handedness = hasattr(hand_res, 'multi_handedness') and hand_res.multi_handedness
        
        for i, hand_landmarks in enumerate(hand_res.multi_hand_landmarks):
            if self.is_hand_raised(hand_landmarks):
                if has_handedness and i < len(hand_res.multi_handedness):
                    side = self.get_hand_side(hand_landmarks, hand_res.multi_handedness[i])
                else:
                    side = self.get_hand_side(hand_landmarks)
                
                if side == "LEFT":
                    left_raised = True
                else:
                    right_raised = True
        
        # Determine gesture
        if left_raised and right_raised:
            return "BOTH_RAISED", True, True
        elif left_raised:
            return "LEFT_RAISED", True, False
        elif right_raised:
            return "RIGHT_RAISED", False, True
        else:
            return "NONE", False, False
    
    def update_gesture_state(self, new_gesture, current_time):
        """Update gesture state with debouncing"""
        self.gesture_history.append((new_gesture, current_time))
        
        # Check if gesture is stable (debouncing)
        if len(self.gesture_history) >= 3:
            recent_gestures = [g for g, _ in list(self.gesture_history)[-3:]]
            if all(g == new_gesture for g in recent_gestures):
                # Gesture is stable
                if new_gesture != self.confirmed_gesture:
                    self.confirmed_gesture = new_gesture
                    self.confirmed_start_time = current_time
                    print(f"[GESTURE CHANGE] {new_gesture} at {time.strftime('%H:%M:%S')}")
        
        return self.confirmed_gesture, self.confirmed_start_time
    
    def get_duration_message(self, gesture, duration, current_time):
        """Get message based on gesture and duration"""
        
        # Reset triggers if gesture changed
        if gesture != "BOTH_RAISED":
            self.distress_triggered = False
        if gesture != "LEFT_RAISED":
            self.alert_triggered = False
        if gesture != "RIGHT_RAISED":
            self.attention_triggered = False
        
        # Check thresholds and generate messages
        if gesture == "BOTH_RAISED":
            if duration >= self.DISTRESS_DURATION:
                if not self.distress_triggered:
                    self.distress_triggered = True
                    print(f"🚨🚨🚨 DISTRESS SIGNAL DETECTED! Both hands raised for {duration:.1f}s 🚨🚨🚨")
                
                elapsed = duration - self.DISTRESS_DURATION
                if elapsed < 2.0:  # First 2 seconds after threshold
                    return f"🚨 DISTRESS! ({elapsed:.1f}s)", (0, 0, 255)  # Red
                else:
                    return "🚨 CONTINUING DISTRESS", (0, 0, 200)  # Darker red
            else:
                remaining = self.DISTRESS_DURATION - duration
                return f"✋✋ Both Hands: {duration:.1f}s ({remaining:.1f}s to Distress)", (255, 165, 0)  # Orange
        
        elif gesture == "LEFT_RAISED":
            if duration >= self.ALERT_DURATION:
                if not self.alert_triggered:
                    self.alert_triggered = True
                    print(f"⚠️⚠️⚠️ ALERT SIGNAL! Left hand raised for {duration:.1f}s ⚠️⚠️⚠️")
                
                elapsed = duration - self.ALERT_DURATION
                if elapsed < 2.0:
                    return f"⚠️ ALERT! ({elapsed:.1f}s)", (255, 0, 0)  # Bright Red
                else:
                    return "⚠️ CONTINUING ALERT", (200, 0, 0)  # Darker red
            else:
                remaining = self.ALERT_DURATION - duration
                return f"👈 Left Hand: {duration:.1f}s ({remaining:.1f}s to Alert)", (255, 255, 0)  # Yellow
        
        elif gesture == "RIGHT_RAISED":
            if duration >= self.ATTENTION_DURATION:
                if not self.attention_triggered:
                    self.attention_triggered = True
                    print(f"🔔🔔🔔 ATTENTION NEEDED! Right hand raised for {duration:.1f}s 🔔🔔🔔")
                
                elapsed = duration - self.ATTENTION_DURATION
                if elapsed < 2.0:
                    return f"🔔 ATTENTION! ({elapsed:.1f}s)", (0, 255, 0)  # Green
                else:
                    return "🔔 NEEDING ATTENTION", (0, 200, 0)  # Darker green
            else:
                remaining = self.ATTENTION_DURATION - duration
                return f"👉 Right Hand: {duration:.1f}s ({remaining:.1f}s to Attention)", (0, 255, 255)  # Cyan
        
        return None, None
    
    def draw_gesture_info(self, frame, gesture, duration):
        """Draw gesture information on frame (for debugging)"""
        h, w = frame.shape[:2]
        
        # Draw threshold indicators
        threshold_y = int(self.RAISE_THRESHOLD * h)
        cv2.line(frame, (0, threshold_y), (w, threshold_y), (0, 255, 255), 1)
        cv2.putText(frame, "Raise Line", (10, threshold_y - 5), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
        
        # Draw hand states
        state_y = 50
        cv2.putText(frame, f"Left: {'↑' if self.left_hand_state else '↓'}", 
                   (w - 150, state_y), cv2.FONT_HERSHEY_SIMPLEX, 0.6, 
                   (0, 255, 0) if self.left_hand_state else (100, 100, 100), 2)
        cv2.putText(frame, f"Right: {'↑' if self.right_hand_state else '↓'}", 
                   (w - 150, state_y + 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                   (0, 255, 0) if self.right_hand_state else (100, 100, 100), 2)
        
        # Draw current gesture
        if gesture != "NONE":
            cv2.putText(frame, f"Gesture: {gesture}", (w - 150, state_y + 60),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
            cv2.putText(frame, f"Duration: {duration:.1f}s", (w - 150, state_y + 90),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
    
    def run(self, frame, annotated, kpts, hand_res):
        """Main plugin execution"""
        import cv2
        
        current_time = time.time()
        
        # Detect current gesture
        gesture, left_raised, right_raised = self.detect_current_gesture(hand_res)
        self.left_hand_state = left_raised
        self.right_hand_state = right_raised
        
        # Update gesture state with debouncing
        confirmed_gesture, gesture_start_time = self.update_gesture_state(gesture, current_time)
        
        # Calculate duration if we have a confirmed gesture
        duration = 0
        if confirmed_gesture != "NONE" and gesture_start_time:
            duration = current_time - gesture_start_time
        
        # Get message based on duration
        message, color = self.get_duration_message(confirmed_gesture, duration, current_time)
        
        # Draw debug information (optional)
        # self.draw_gesture_info(annotated, confirmed_gesture, duration)
        
        # Update display
        if message:
            self.current_message = message
            self.message_color = color
            self.last_update_time = current_time
            
            # Also draw on the annotated frame
            cv2.putText(annotated, message, (20, 100),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.9, color, 3)
            
            # Draw duration bar at top
            if confirmed_gesture != "NONE":
                bar_width = int((duration / max(self.DISTRESS_DURATION, self.ALERT_DURATION, self.ATTENTION_DURATION)) * 300)
                bar_width = min(300, bar_width)
                
                cv2.rectangle(annotated, (20, 20), (20 + bar_width, 40), color, -1)
                cv2.rectangle(annotated, (20, 20), (320, 40), (255, 255, 255), 2)
                
                threshold_text = ""
                if confirmed_gesture == "BOTH_RAISED":
                    threshold_text = f"Distress in: {max(0, self.DISTRESS_DURATION - duration):.1f}s"
                elif confirmed_gesture == "LEFT_RAISED":
                    threshold_text = f"Alert in: {max(0, self.ALERT_DURATION - duration):.1f}s"
                elif confirmed_gesture == "RIGHT_RAISED":
                    threshold_text = f"Attention in: {max(0, self.ATTENTION_DURATION - duration):.1f}s"
                
                cv2.putText(annotated, threshold_text, (330, 35),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            
            return message, color
        
        # Clear message if no gesture
        elif current_time - self.last_update_time > 1.0:  # Keep message for 1 second after gesture ends
            self.current_message = ""
        
        return None, None