# plugins/help_gesture.py
import time
from collections import deque
import numpy as np

class Plugin:
    def __init__(self):
        self.left_waves = deque(maxlen=20)
        self.right_waves = deque(maxlen=20)
        self.times = deque(maxlen=20)
        self.LW = 9; self.RW = 10
        self.LS = 5; self.RS = 6

    def is_hand_raised(self, kpts, wrist, shoulder):
        try:
            return kpts[wrist][1] < kpts[shoulder][1]
        except:
            return False

    def detect_slow_wave(self, xs):
        if len(xs) < 8:
            return False
        arr = np.array(xs)
        amp = arr.max() - arr.min()
        diffs = np.diff(arr)
        sign_changes = np.sum((diffs[:-1] * diffs[1:]) < 0)
        return sign_changes >= 1 and amp > 0.04

    def run(self, frame, annotated, kpts, hand_res):
        # uses MediaPipe hands if available to collect wrist x positions
        if not getattr(hand_res, "multi_hand_landmarks", None):
            self.left_waves.clear(); self.right_waves.clear(); self.times.clear()
            return None, None
        try:
            t = time.time()
            for hand in hand_res.multi_hand_landmarks:
                x_avg = sum([lm.x for lm in hand.landmark]) / 21
                wrist_x = hand.landmark[9].x
                if x_avg < 0.5:
                    self.left_waves.append(wrist_x)
                else:
                    self.right_waves.append(wrist_x)
                self.times.append(t)

            left_ok = self.detect_slow_wave(self.left_waves)
            right_ok = self.detect_slow_wave(self.right_waves)

            # combine with hand raise from pose (if available)
            left_raised = False; right_raised = False
            if kpts is not None:
                left_raised = self.is_hand_raised(kpts, self.LW, self.LS)
                right_raised = self.is_hand_raised(kpts, self.RW, self.RS)

            if (left_ok and left_raised):
                return "HELP GESTURE (Left)", (0, 140, 255)
            if (right_ok and right_raised):
                return "HELP GESTURE (Right)", (0, 140, 255)

        except Exception:
            return None, None
        return None, None
