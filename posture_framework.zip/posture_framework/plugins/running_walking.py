# plugins/running_walking.py
import numpy as np
import time
from collections import deque

class Plugin:
    def __init__(self):
        # buffer for centroids and times
        self.centers = deque(maxlen=8)
        self.times = deque(maxlen=8)
        # keypoints for centroid (use hip midpoint)
        self.LH = 11
        self.RH = 12

    def run(self, frame, annotated, kpts, hand_res):
        if kpts is None:
            return None, None
        try:
            t = time.time()
            hip_mid = (kpts[self.LH][:2] + kpts[self.RH][:2]) / 2.0
            self.centers.append(hip_mid)
            self.times.append(t)

            if len(self.centers) < 4:
                return None, None

            # compute average speed (euclidean change per second)
            dt = self.times[-1] - self.times[0]
            if dt <= 0:
                return None, None
            dist = np.linalg.norm(self.centers[-1] - self.centers[0])
            speed = dist / dt  # normalized per image coords

            # thresholds (tuned for typical webcam/altitude)
            if speed > 0.02:
                return "RUNNING", (255, 0, 0)
            if speed > 0.006:
                return "WALKING", (0, 255, 255)

        except Exception:
            return None, None
        return None, None
