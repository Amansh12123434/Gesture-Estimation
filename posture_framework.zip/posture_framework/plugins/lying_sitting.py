# plugins/lying_sitting.py
import numpy as np

class Plugin:
    def __init__(self):
        self.LS = 5
        self.RS = 6
        self.LH = 11
        self.RH = 12
        self.LA = 15
        self.RA = 16

    def run(self, frame, annotated, kpts, hand_res):
        if kpts is None:
            return None, None
        try:
            # torso angle similar to fall plugin
            ls = kpts[self.LS][:2]
            rs = kpts[self.RS][:2]
            lh = kpts[self.LH][:2]
            rh = kpts[self.RH][:2]
            la = kpts[self.LA][:2]
            ra = kpts[self.RA][:2]

            shoulder_mid = (ls + rs) / 2.0
            hip_mid = (lh + rh) / 2.0
            ankle_mid = (la + ra) / 2.0

            vec = hip_mid - shoulder_mid
            angle_deg = abs(np.degrees(np.arctan2(vec[1], vec[0])))

            # vertical distances
            shoulder_y = shoulder_mid[1]
            hip_y = hip_mid[1]
            ankle_y = ankle_mid[1]

            # heuristics (image coordinates: smaller y => higher on image)
            # Lying: torso more horizontal (angle < ~35) and hip close to ankle (hip_y approx == ankle_y)
            if angle_deg < 35 and abs(hip_y - ankle_y) < 0.08:
                return "LYING (possible injury)", (0, 0, 200)

            # Sitting: hip is much lower than shoulders but far above ankles
            if (hip_y - shoulder_y) > 0.08 and (ankle_y - hip_y) > 0.06:
                return "SITTING/ CROUCHED", (0, 165, 255)

            # otherwise standing
            return None, None
        except Exception:
            return None, None
