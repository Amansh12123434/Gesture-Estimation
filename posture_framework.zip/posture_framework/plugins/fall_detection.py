# plugins/fall_detection.py
import numpy as np
import time
from collections import deque

class Plugin:
    def __init__(self):
        # keep last N torso angles and hip-y values
        self.angles = deque(maxlen=8)
        self.hip_ys = deque(maxlen=8)
        self.times = deque(maxlen=8)
        # keypoint indices (YOLO pose)
        self.LEFT_SHOULDER = 5
        self.RIGHT_SHOULDER = 6
        self.LEFT_HIP = 11
        self.RIGHT_HIP = 12

    def torso_angle(self, kpts):
        ls = kpts[self.LEFT_SHOULDER][:2]
        rs = kpts[self.RIGHT_SHOULDER][:2]
        lh = kpts[self.LEFT_HIP][:2]
        rh = kpts[self.RIGHT_HIP][:2]
        shoulder_mid = (ls + rs) / 2.0
        hip_mid = (lh + rh) / 2.0
        vec = hip_mid - shoulder_mid
        angle = np.degrees(np.arctan2(vec[1], vec[0]))  # angle in degrees
        return abs(angle)  # use magnitude

    def run(self, frame, annotated, kpts, hand_res):
        if kpts is None:
            return None, None
        t = time.time()
        try:
            angle = self.torso_angle(kpts)
            hip_mid_y = (kpts[self.LEFT_HIP][1] + kpts[self.RIGHT_HIP][1]) / 2.0

            self.angles.append(angle)
            self.hip_ys.append(hip_mid_y)
            self.times.append(t)

            # need at least 4 samples
            if len(self.angles) < 4:
                return None, None

            # compute angle drop or change - if torso becomes near-horizontal (small angle) quickly -> fall
            angle_change = self.angles[0] - self.angles[-1]
            # compute hip vertical velocity (normalized by time)
            dt = self.times[-1] - self.times[0]
            if dt <= 0:
                return None, None
            hip_velocity = (self.hip_ys[-1] - self.hip_ys[0]) / dt  # positive means hip moves downward in image coords

            # thresholds tuned empirically (YOLO coords: y increases downward on image)
            if angle_change > 20 and hip_velocity > 0.005:
                return "FALL/ COLLAPSE (possible)", (0, 0, 255)

        except Exception:
            return None, None

        return None, None
