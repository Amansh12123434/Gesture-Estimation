"""
Finger Counter - Using your exact logic with corrected labels
"""

import numpy as np
import mediapipe as mp

class Plugin:
    def __init__(self):
        self.name = "Finger Counter"
        self.description = "Uses your original finger counting logic"
    
    def run(self, frame, annotated, kpts, hand_res):
        """Your exact logic from the original program"""
        if not (hand_res and hand_res.multi_hand_landmarks):
            return None, None
        
        gesture_description = ""
        total_fingers = 0
        
        # Check if we have handedness info
        has_handedness = hasattr(hand_res, 'multi_handedness') and hand_res.multi_handedness
        
        if has_handedness:
            # Use your exact logic with MediaPipe handedness
            for hand_landmarks, handedness in zip(hand_res.multi_hand_landmarks, hand_res.multi_handedness):
                hand_label = handedness.classification[0].label
                fingers_up = 0
                
                # YOUR ORIGINAL THUMB LOGIC:
                if hand_label == "Right":
                    thumb_up = hand_landmarks.landmark[mp.solutions.hands.HandLandmark.THUMB_TIP].x < \
                              hand_landmarks.landmark[mp.solutions.hands.HandLandmark.THUMB_IP].x
                else:  # Left hand
                    thumb_up = hand_landmarks.landmark[mp.solutions.hands.HandLandmark.THUMB_TIP].x > \
                              hand_landmarks.landmark[mp.solutions.hands.HandLandmark.THUMB_IP].x
                
                if thumb_up:
                    fingers_up += 1
                
                # YOUR ORIGINAL FINGER LOGIC:
                for tip, pip in [
                    (mp.solutions.hands.HandLandmark.INDEX_FINGER_TIP, mp.solutions.hands.HandLandmark.INDEX_FINGER_PIP),
                    (mp.solutions.hands.HandLandmark.MIDDLE_FINGER_TIP, mp.solutions.hands.HandLandmark.MIDDLE_FINGER_PIP),
                    (mp.solutions.hands.HandLandmark.RING_FINGER_TIP, mp.solutions.hands.HandLandmark.RING_FINGER_PIP),
                    (mp.solutions.hands.HandLandmark.PINKY_TIP, mp.solutions.hands.HandLandmark.PINKY_PIP)
                ]:
                    if hand_landmarks.landmark[tip].y < hand_landmarks.landmark[pip].y:
                        fingers_up += 1
                
                total_fingers += fingers_up
                gesture_description += f"{hand_label}:{fingers_up} "
        
        # Create the final message
        if gesture_description:
            # FIX: Swap Left/Right labels
            message = gesture_description.replace("Left:", "RIGHT:").replace("Right:", "LEFT:")
            message = message.replace("LEFT:", "L:").replace("RIGHT:", "R:")
        else:
            # Fallback if no handedness info
            for hand_landmarks in hand_res.multi_hand_landmarks:
                fingers_up = 0
                
                # Simple finger counting without handedness
                for tip, pip in [(8, 6), (12, 10), (16, 14), (20, 18)]:
                    if hand_landmarks.landmark[tip].y < hand_landmarks.landmark[pip].y:
                        fingers_up += 1
                
                total_fingers += fingers_up
            
            message = f"Total: {total_fingers} fingers"
        
        # Color coding
        if total_fingers == 0:
            color = (150, 150, 150)
        elif total_fingers <= 3:
            color = (0, 255, 0)
        elif total_fingers <= 6:
            color = (255, 255, 0)
        elif total_fingers <= 8:
            color = (255, 165, 0)
        else:
            color = (255, 0, 0)
        
        return message.strip(), color